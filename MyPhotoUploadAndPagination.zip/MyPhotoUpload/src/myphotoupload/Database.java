/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myphotoupload;
import java.sql.*;

/**
 *
 * @author soe wai moe
 */
public class Database {
    
    public Connection getConneted(){
        
        Connection conn=null;
        try{
            
            Class.forName("org.sqlite.JDBC");
            conn=DriverManager.getConnection("jdbc:sqlite:mydb1.db");
            
            if(conn!=null){
                System.out.println("Database Connection Success....");
            }
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        return conn;
    }
    
}
